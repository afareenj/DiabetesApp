//
//  Day.swift
//  FoodTracker
//
//  Created by Afareen Jaleel on 12/31/17.
//  Copyright © 2017 Apple Inc. All rights reserved.
//

import UIKit
import os.log
class Day: NSObject, NSCoding {
    //MARK: Properties
    var cal: Int
    var sugar: Int
    var exercise: String
    var med: Bool
    var ex: Bool
    
    //MARK: Archiving Paths
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("days")
    
    //MARK: Types
    struct PropertyKey {
        static let cal = "cal"
        static let sugar = "sugar"
        static let exercise = "exercise"
        static let med = "med"
        static let ex = "ex"
    }
    
    //MARK: Initialization
    init?(cal: Int, sugar: Int, exercise: String, med: Bool, ex: Bool) {
        guard  cal>=0 && sugar>=0 && !exercise.isEmpty else {
            return nil
        }
        self.cal = cal
        self.sugar = sugar
        self.exercise = exercise
        self.med = med
        self.ex = ex
    }
    
    //MARK: NSCoding
    func encode(with aCoder: NSCoder) {
        aCoder.encode(cal, forKey: PropertyKey.cal)
        aCoder.encode(sugar, forKey: PropertyKey.sugar)
        aCoder.encode(exercise, forKey: PropertyKey.exercise)
        aCoder.encode(med, forKey: PropertyKey.med)
        aCoder.encode(ex, forKey: PropertyKey.ex)
    }
    required convenience init?(coder aDecoder: NSCoder) {
        let cal = aDecoder.decodeInteger(forKey: PropertyKey.cal)
        let sugar = aDecoder.decodeInteger(forKey: PropertyKey.sugar)
        guard let exercise = aDecoder.decodeObject(forKey: PropertyKey.exercise) as? String else {
            os_log("Unable to decode the name for a Meal object.", log: OSLog.default, type: .debug)
            return nil
        }
        let med = aDecoder.decodeBool(forKey: PropertyKey.med)
        let ex = aDecoder.decodeBool(forKey: PropertyKey.ex)
        self.init(cal: cal, sugar: sugar, exercise: exercise, med: med, ex: ex)
    }
}
