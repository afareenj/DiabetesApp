//
//  DayViewController.swift
//  FoodTracker
//
//  Created by Afareen Jaleel on 1/1/18.
//  Copyright © 2018 Afareen Jaleel. All rights reserved.
//

import UIKit
import os.log

class DayViewController: UIViewController{

    //MARK: Properties
    var days: Day?
    var meals = [Meal]()
    @IBOutlet weak var calLabel: UILabel!
    @IBOutlet weak var sugarLabel: UILabel!
    @IBOutlet weak var exerciseLabel: UILabel!
    @IBOutlet weak var medLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let savedDays = loadDays() {
            days = savedDays
        }
        else {
            loadSampleDay()
        }
        if let savedMeals = loadMeals() {
            meals += savedMeals
        }
        else {
            loadSampleMeals()
        }
        data()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    //MARK: Private Methods
    private func data() {
        var actualCalories: Int
        var actualSugar: Int
        actualCalories = 0
        actualSugar = 0
        if (meals.isEmpty) {
            actualCalories = 0
            actualSugar = 0
        }
        else {
            for meal in meals {
                actualCalories += meal.calories
                actualSugar += meal.sugar
            }
        }
        calLabel.text = "Today's consumed calories: " + "\(actualCalories)" + " of " + "\(days!.cal)"
        sugarLabel.text = "Today's sugar intake: " + "\(actualSugar)" + " out of " + "\(days!.sugar)"
        if (days!.ex == true) {
            exerciseLabel.text = "You have exercised today! Yay!"
        }
        else {
            exerciseLabel.text = "You have not yet exercised today."
        }
        if (days!.med == true) {
            medLabel.text = "You have taken your medicine today."
        }
        else {
            medLabel.text = "You have not yet taken your medicine today."
        }
    }
    
    private func loadSampleMeals() {
        
        let photo1 = UIImage(named: "meal1")
        let photo2 = UIImage(named: "meal2")
        let photo3 = UIImage(named: "meal3")
        
        guard let meal1 = Meal(name: "Caprese Salad", photo: photo1, rating: 4, calories: 0, sugar: 0) else {
            fatalError("Unable to instantiate meal1")
        }
        
        guard let meal2 = Meal(name: "Chicken and Potatoes", photo: photo2, rating: 5, calories: 0, sugar: 0) else {
            fatalError("Unable to instantiate meal2")
        }
        
        guard let meal3 = Meal(name: "Pasta with Meatballs", photo: photo3, rating: 3, calories: 0, sugar: 0) else {
            fatalError("Unable to instantiate meal2")
        }
        
        meals += [meal1, meal2, meal3]
    }
    private func loadSampleDay() {
        guard let day = Day(cal: 0, sugar: 0, exercise: "0", med: false, ex: false) else {
            fatalError("Unable to instantiate day")
        }
        days = day
    }
    private func saveDays() {
        let isSuccessfulSave = NSKeyedArchiver.archiveRootObject(days!, toFile: Day.ArchiveURL.path)
        if isSuccessfulSave {
            os_log("Days successfully saved.", log: OSLog.default, type: .debug)
        } else {
            os_log("Failed to save days...", log: OSLog.default, type: .error)
        }
    }
    private func loadDays() -> Day?  {
        return NSKeyedUnarchiver.unarchiveObject(withFile: Day.ArchiveURL.path) as? Day
    }
    private func saveMeals() {
        let isSuccessfulSave = NSKeyedArchiver.archiveRootObject(meals, toFile: Meal.ArchiveURL.path)
        if isSuccessfulSave {
            os_log("Meals successfully saved.", log: OSLog.default, type: .debug)
        } else {
            os_log("Failed to save meals...", log: OSLog.default, type: .error)
        }
    }
    
    private func loadMeals() -> [Meal]?  {
        return NSKeyedUnarchiver.unarchiveObject(withFile: Meal.ArchiveURL.path) as? [Meal]
    }
}
