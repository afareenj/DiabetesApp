//
//  SettingViewController.swift
//  FoodTracker
//
//  Created by Afareen Jaleel on 1/1/18.
//  Copyright © 2018 Afareen Jaleel. All rights reserved.
//

import UIKit
import os.log

class SettingViewController: UIViewController, UITextFieldDelegate, UINavigationControllerDelegate {

    //MARK: Properties
    var days: Day?
    @IBOutlet weak var calTextField: UITextField!
    @IBOutlet weak var sugarTextField: UITextField!
    @IBOutlet weak var exerciseTextField: UITextField!
    @IBOutlet weak var saveButton: UIBarButtonItem!
    @IBOutlet weak var exerciseSwitch: UISwitch!
    @IBOutlet weak var medSwitch: UISwitch!
    @IBOutlet weak var resetButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        calTextField.delegate = self
        sugarTextField.delegate = self
        exerciseTextField.delegate = self
        //Set up views if editing an existing Day.
        if let day = days {
            calTextField.text = "\(day.cal)"
            sugarTextField.text = "\(day.sugar)"
            exerciseTextField.text = day.exercise
        }
        // Enable the See button only if the text fields are filled
        updateSeeButtonState()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //MARK: UITextFieldDelegate
    func textFieldDidBeginEditing(_ textField: UITextField) {
        // Disable the See button while editing.
        saveButton.isEnabled = false
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        updateSeeButtonState()
    }
    //MARK: Navigation
    //This method lets you configure a view controller before it's presented.
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        //Configure the destination view controller only when the see yourday button is pressed.
        guard let button = sender as? UIBarButtonItem, button === saveButton else {
            os_log("The see yourday button was not pressed, cancelling", log: OSLog.default, type: .debug)
            return
        }
        let cal = (calTextField.text! as NSString).integerValue
        let sugar = (sugarTextField.text! as NSString).integerValue
        let exercise = exerciseTextField.text
        let med = medSwitch.isOn
        let ex = exerciseSwitch.isOn
        days = Day(cal: cal, sugar: sugar, exercise: exercise!, med: med, ex: ex)
        saveDays()
    }
    //MARK: Actions
    @IBAction func setDefaultSwitches(_ sender: UIButton) {
        medSwitch.setOn(false, animated: true)
        exerciseSwitch.setOn(false, animated: true)
    }
    
    //MARK: Private Methods
    private func updateSeeButtonState() {
        // Disable the Save button if the text field is empty.
        let text = exerciseTextField.text ?? ""
        let text2 = calTextField.text ?? ""
        let text3 = sugarTextField.text ?? ""
        saveButton.isEnabled = !text.isEmpty && !text2.isEmpty && !text3.isEmpty
    }

    private func loadSampleDay() {
        guard let day = Day(cal: 0, sugar: 0, exercise: "0", med: false, ex: false) else {
            fatalError("Unable to instantiate day")
        }
        days = day
    }
    private func saveDays() {
        let isSuccessfulSave = NSKeyedArchiver.archiveRootObject(days!, toFile: Day.ArchiveURL.path)
        if isSuccessfulSave {
            os_log("Days successfully saved.", log: OSLog.default, type: .debug)
        } else {
            os_log("Failed to save days...", log: OSLog.default, type: .error)
        }
    }
    private func loadDays() -> Day?  {
        return NSKeyedUnarchiver.unarchiveObject(withFile: Day.ArchiveURL.path) as? Day
    }

}
